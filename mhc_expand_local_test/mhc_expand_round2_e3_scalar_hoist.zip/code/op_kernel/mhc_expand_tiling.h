// Host-to-kernel tiling data for MhcExpand.
#pragma once

#include <cstdint>

struct MhcExpandTilingData {
    uint64_t s;
    uint64_t d;
    uint32_t mhcMult;
    uint32_t backward;
    uint32_t tileLength;
    uint32_t rowBlock;
    uint32_t blockDim;
    // Derived task geometry, precomputed by Host so the kernel avoids
    // non-constant 64-bit divisions: tilesPerRow = ceil(d / tileLength),
    // taskCount = ceil(s / rowBlock) * tilesPerRow.
    uint32_t tilesPerRow;
    uint64_t taskCount;
};
static_assert(sizeof(MhcExpandTilingData) == 48, "unexpected tiling ABI size");

