// MhcExpand forward/backward kernel.
#include "kernel_operator.h"

#include "mhc_expand_tiling.h"
#include "tiling_key_mhc_expand.h"

namespace {
constexpr uint32_t BLOCK_BYTES = 32;
}

template <class DT_X>
class KernelMhcExpand {
public:
    __aicore__ inline KernelMhcExpand() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR o, const MhcExpandTilingData &tiling) {
        s_ = tiling.s;
        d_ = tiling.d;
        mhcMult_ = tiling.mhcMult;
        backward_ = tiling.backward != 0;
        tileLength_ = tiling.tileLength;
        blockDim_ = tiling.blockDim;
        tilesPerRow_ = (d_ + tileLength_ - 1) / tileLength_;

        const uint64_t inputLength = backward_ ? s_ * mhcMult_ * d_ : s_ * d_;
        const uint64_t outputLength = backward_ ? s_ * d_ : s_ * mhcMult_ * d_;
        xGm_.SetGlobalBuffer((__gm__ DT_X *)x, inputLength);
        oGm_.SetGlobalBuffer((__gm__ DT_X *)o, outputLength);

        pipe_.InitBuffer(inQueue_, 1, tileLength_ * sizeof(DT_X));
        pipe_.InitBuffer(outQueue_, 1, tileLength_ * sizeof(DT_X));
        pipe_.InitBuffer(valueFp32Buf_, tileLength_ * sizeof(float));
        pipe_.InitBuffer(accFp32Buf_, tileLength_ * sizeof(float));
    }

    __aicore__ inline void Process() {
        const uint64_t taskCount = s_ * tilesPerRow_;
        for (uint64_t task = AscendC::GetBlockIdx(); task < taskCount; task += blockDim_) {
            const uint64_t row = task / tilesPerRow_;
            const uint64_t columnOffset = (task % tilesPerRow_) * tileLength_;
            const uint32_t validLength = static_cast<uint32_t>(
                ((d_ - columnOffset) < tileLength_) ? (d_ - columnOffset) : tileLength_);
            const uint32_t alignedLength = AlignUp(validLength);
            if (backward_) {
                ProcessBackward(row, columnOffset, validLength, alignedLength);
            } else {
                ProcessForward(row, columnOffset, validLength, alignedLength);
            }
        }
    }

private:
    __aicore__ inline uint32_t AlignUp(uint32_t length) const {
        constexpr uint32_t elementsPerBlock = BLOCK_BYTES / sizeof(DT_X);
        return (length + elementsPerBlock - 1) / elementsPerBlock * elementsPerBlock;
    }

    __aicore__ inline void CopyIn(uint64_t offset, uint32_t validLength, uint32_t alignedLength) {
        AscendC::LocalTensor<DT_X> xLocal = inQueue_.AllocTensor<DT_X>();
        const uint32_t copyBytes = validLength * static_cast<uint32_t>(sizeof(DT_X));
        AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
        AscendC::DataCopyPadExtParams<DT_X> padParams{
            true, 0, static_cast<uint8_t>(alignedLength - validLength), static_cast<DT_X>(0)};
        AscendC::DataCopyPad(xLocal, xGm_[offset], copyParams, padParams);
        inQueue_.EnQue(xLocal);
    }

    __aicore__ inline void CopyOut(const AscendC::LocalTensor<DT_X> &oLocal, uint64_t offset,
                                   uint32_t validLength) {
        const uint32_t copyBytes = validLength * static_cast<uint32_t>(sizeof(DT_X));
        AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
        AscendC::DataCopyPad(oGm_[offset], oLocal, copyParams);
    }

    __aicore__ inline void CastFromFloat(AscendC::LocalTensor<DT_X> &dst,
                                         const AscendC::LocalTensor<float> &src,
                                         uint32_t length) {
        if constexpr (AscendC::IsSameType<DT_X, bfloat16_t>::value) {
            AscendC::Cast(dst, src, AscendC::RoundMode::CAST_RINT, length);
        } else {
            AscendC::Cast(dst, src, AscendC::RoundMode::CAST_NONE, length);
        }
    }

    __aicore__ inline void ProcessForward(uint64_t row, uint64_t columnOffset,
                                           uint32_t validLength, uint32_t alignedLength) {
        const uint64_t inputOffset = row * d_ + columnOffset;
        CopyIn(inputOffset, validLength, alignedLength);

        AscendC::LocalTensor<DT_X> xLocal = inQueue_.DeQue<DT_X>();
        AscendC::LocalTensor<DT_X> oLocal = outQueue_.AllocTensor<DT_X>();
        AscendC::DataCopy(oLocal, xLocal, alignedLength);
        outQueue_.EnQue(oLocal);
        inQueue_.FreeTensor(xLocal);

        oLocal = outQueue_.DeQue<DT_X>();
        for (uint32_t replica = 0; replica < mhcMult_; ++replica) {
            const uint64_t outputOffset = (row * mhcMult_ + replica) * d_ + columnOffset;
            CopyOut(oLocal, outputOffset, validLength);
        }
        outQueue_.FreeTensor(oLocal);
    }

    __aicore__ inline void ProcessBackward(uint64_t row, uint64_t columnOffset,
                                            uint32_t validLength, uint32_t alignedLength) {
        AscendC::LocalTensor<float> valueFp32 = valueFp32Buf_.Get<float>();
        AscendC::LocalTensor<float> accumulator = accFp32Buf_.Get<float>();
        AscendC::Duplicate(accumulator, 0.0f, alignedLength);
        AscendC::PipeBarrier<PIPE_V>();

        for (uint32_t replica = 0; replica < mhcMult_; ++replica) {
            const uint64_t inputOffset = (row * mhcMult_ + replica) * d_ + columnOffset;
            CopyIn(inputOffset, validLength, alignedLength);
            AscendC::LocalTensor<DT_X> xLocal = inQueue_.DeQue<DT_X>();
            AscendC::Cast(valueFp32, xLocal, AscendC::RoundMode::CAST_NONE, alignedLength);
            AscendC::PipeBarrier<PIPE_V>();
            AscendC::Add(accumulator, accumulator, valueFp32, alignedLength);
            AscendC::PipeBarrier<PIPE_V>();
            inQueue_.FreeTensor(xLocal);
        }

        AscendC::LocalTensor<DT_X> oLocal = outQueue_.AllocTensor<DT_X>();
        CastFromFloat(oLocal, accumulator, alignedLength);
        outQueue_.EnQue(oLocal);
        oLocal = outQueue_.DeQue<DT_X>();
        CopyOut(oLocal, row * d_ + columnOffset, validLength);
        outQueue_.FreeTensor(oLocal);
    }

    AscendC::TPipe pipe_;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue_;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> valueFp32Buf_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> accFp32Buf_;
    AscendC::GlobalTensor<DT_X> xGm_;
    AscendC::GlobalTensor<DT_X> oGm_;
    uint64_t s_ = 0;
    uint64_t d_ = 0;
    uint64_t tilesPerRow_ = 0;
    uint32_t mhcMult_ = 0;
    uint32_t tileLength_ = 0;
    uint32_t blockDim_ = 0;
    bool backward_ = false;
};

template <typename DT_X>
__global__ __aicore__ void mhc_expand(GM_ADDR x, GM_ADDR o, GM_ADDR workspace, GM_ADDR tiling) {
    REGISTER_TILING_DEFAULT(MhcExpandTilingData);
    GET_TILING_DATA_WITH_STRUCT(MhcExpandTilingData, tiling_data, tiling);
    KernelMhcExpand<DT_X> op;
    op.Init(x, o, tiling_data);
    op.Process();
}
