// MhcExpand forward/backward kernel.
#include "kernel_operator.h"

#include "mhc_expand_tiling.h"
#include "tiling_key_mhc_expand.h"

namespace {
constexpr uint32_t BLOCK_BYTES = 32;
}

template <class DT_X>
class KernelMhcExpand {
public:
    __aicore__ inline KernelMhcExpand() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR o, const MhcExpandTilingData &tiling) {
        s_ = tiling.s;
        d_ = tiling.d;
        mhcMult_ = tiling.mhcMult;
        backward_ = tiling.backward != 0;
        tileLength_ = tiling.tileLength;
        blockDim_ = tiling.blockDim;
        tilesPerRow_ = (d_ + tileLength_ - 1) / tileLength_;

        const uint64_t inputLength = backward_ ? s_ * mhcMult_ * d_ : s_ * d_;
        const uint64_t outputLength = backward_ ? s_ * d_ : s_ * mhcMult_ * d_;
        xGm_.SetGlobalBuffer((__gm__ DT_X *)x, inputLength);
        oGm_.SetGlobalBuffer((__gm__ DT_X *)o, outputLength);

        if (backward_) {
            // Two input buffers let MTE2 prefetch the next replica while the
            // vector pipe converts and accumulates the current one.
            pipe_.InitBuffer(inQueue_, 2, tileLength_ * sizeof(DT_X));
            pipe_.InitBuffer(outQueue_, 1, tileLength_ * sizeof(DT_X));
            if constexpr (AscendC::IsSameType<DT_X, half>::value) {
                if (mhcMult_ != 2) {
                    pipe_.InitBuffer(valueFp32Buf_, tileLength_ * sizeof(float));
                    pipe_.InitBuffer(accFp32Buf_, tileLength_ * sizeof(float));
                }
            } else {
                pipe_.InitBuffer(valueFp32Buf_, tileLength_ * sizeof(float));
                pipe_.InitBuffer(accFp32Buf_, tileLength_ * sizeof(float));
            }
        } else {
            // Forward only moves data between GM and UB. A single raw buffer
            // avoids two queue initializations and the previous UB-to-UB copy.
            pipe_.InitBuffer(forwardBuf_, tileLength_ * sizeof(DT_X));
        }
    }

    __aicore__ inline void Process() {
        const uint64_t taskCount = s_ * tilesPerRow_;
        if (!backward_) {
            if (blockDim_ > taskCount) {
                ProcessForwardReplicaTasks(taskCount);
            } else {
                ProcessForwardTasks(taskCount);
            }
            return;
        }
        for (uint64_t task = AscendC::GetBlockIdx(); task < taskCount; task += blockDim_) {
            const uint64_t row = task / tilesPerRow_;
            const uint64_t columnOffset = (task % tilesPerRow_) * tileLength_;
            const uint32_t validLength = static_cast<uint32_t>(
                ((d_ - columnOffset) < tileLength_) ? (d_ - columnOffset) : tileLength_);
            const uint32_t alignedLength = AlignUp(validLength);
            ProcessBackward(row, columnOffset, validLength, alignedLength);
        }
    }

private:
    __aicore__ inline uint32_t AlignUp(uint32_t length) const {
        constexpr uint32_t elementsPerBlock = BLOCK_BYTES / sizeof(DT_X);
        return (length + elementsPerBlock - 1) / elementsPerBlock * elementsPerBlock;
    }

    __aicore__ inline bool IsBlockAligned(uint64_t offset, uint32_t length) const {
        constexpr uint32_t elementsPerBlock = BLOCK_BYTES / sizeof(DT_X);
        return (offset % elementsPerBlock == 0) && (length % elementsPerBlock == 0);
    }

    __aicore__ inline void CopyIn(uint64_t offset, uint32_t validLength, uint32_t alignedLength) {
        AscendC::LocalTensor<DT_X> xLocal = inQueue_.AllocTensor<DT_X>();
        if (IsBlockAligned(offset, validLength)) {
            AscendC::DataCopy(xLocal, xGm_[offset], alignedLength);
        } else {
            const uint32_t copyBytes = validLength * static_cast<uint32_t>(sizeof(DT_X));
            AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
            AscendC::DataCopyPadExtParams<DT_X> padParams{
                true, 0, static_cast<uint8_t>(alignedLength - validLength), static_cast<DT_X>(0)};
            AscendC::DataCopyPad(xLocal, xGm_[offset], copyParams, padParams);
        }
        inQueue_.EnQue(xLocal);
    }

    __aicore__ inline void CopyOut(const AscendC::LocalTensor<DT_X> &oLocal, uint64_t offset,
                                   uint32_t validLength) {
        if (IsBlockAligned(offset, validLength)) {
            AscendC::DataCopy(oGm_[offset], oLocal, validLength);
        } else {
            const uint32_t copyBytes = validLength * static_cast<uint32_t>(sizeof(DT_X));
            AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
            AscendC::DataCopyPad(oGm_[offset], oLocal, copyParams);
        }
    }

    __aicore__ inline void CastFromFloat(AscendC::LocalTensor<DT_X> &dst,
                                         const AscendC::LocalTensor<float> &src,
                                         uint32_t length) {
        if constexpr (AscendC::IsSameType<DT_X, bfloat16_t>::value) {
            AscendC::Cast(dst, src, AscendC::RoundMode::CAST_RINT, length);
        } else {
            AscendC::Cast(dst, src, AscendC::RoundMode::CAST_NONE, length);
        }
    }

    __aicore__ inline void ProcessForwardTasks(uint64_t taskCount) {
        AscendC::LocalTensor<DT_X> xLocal = forwardBuf_.Get<DT_X>();
        const event_t mte2ToMte3 = static_cast<event_t>(
            GetTPipePtr()->FetchEventID(AscendC::HardEvent::MTE2_MTE3));
        const event_t mte3ToMte2 = static_cast<event_t>(
            GetTPipePtr()->FetchEventID(AscendC::HardEvent::MTE3_MTE2));
        AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(mte3ToMte2);

        for (uint64_t task = AscendC::GetBlockIdx(); task < taskCount; task += blockDim_) {
            const uint64_t row = task / tilesPerRow_;
            const uint64_t columnOffset = (task % tilesPerRow_) * tileLength_;
            const uint32_t validLength = static_cast<uint32_t>(
                ((d_ - columnOffset) < tileLength_) ? (d_ - columnOffset) : tileLength_);
            const uint32_t alignedLength = AlignUp(validLength);
            const uint64_t inputOffset = row * d_ + columnOffset;

            AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(mte3ToMte2);
            if (IsBlockAligned(inputOffset, validLength)) {
                AscendC::DataCopy(xLocal, xGm_[inputOffset], alignedLength);
            } else {
                const uint32_t copyBytes = validLength * static_cast<uint32_t>(sizeof(DT_X));
                AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
                AscendC::DataCopyPadExtParams<DT_X> padParams{
                    true, 0, static_cast<uint8_t>(alignedLength - validLength), static_cast<DT_X>(0)};
                AscendC::DataCopyPad(xLocal, xGm_[inputOffset], copyParams, padParams);
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(mte2ToMte3);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(mte2ToMte3);

            for (uint32_t replica = 0; replica < mhcMult_; ++replica) {
                const uint64_t outputOffset = (row * mhcMult_ + replica) * d_ + columnOffset;
                if (IsBlockAligned(outputOffset, validLength)) {
                    AscendC::DataCopy(oGm_[outputOffset], xLocal, alignedLength);
                } else {
                    const uint32_t copyBytes = validLength * static_cast<uint32_t>(sizeof(DT_X));
                    AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
                    AscendC::DataCopyPad(oGm_[outputOffset], xLocal, copyParams);
                }
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(mte3ToMte2);
        }
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(mte3ToMte2);
    }

    __aicore__ inline void ProcessForwardReplicaTasks(uint64_t baseTaskCount) {
        AscendC::LocalTensor<DT_X> xLocal = forwardBuf_.Get<DT_X>();
        const event_t mte2ToMte3 = static_cast<event_t>(
            GetTPipePtr()->FetchEventID(AscendC::HardEvent::MTE2_MTE3));
        const event_t mte3ToMte2 = static_cast<event_t>(
            GetTPipePtr()->FetchEventID(AscendC::HardEvent::MTE3_MTE2));
        const uint64_t taskCount = baseTaskCount * mhcMult_;
        AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(mte3ToMte2);

        for (uint64_t task = AscendC::GetBlockIdx(); task < taskCount; task += blockDim_) {
            const uint64_t baseTask = task / mhcMult_;
            const uint32_t replica = static_cast<uint32_t>(task % mhcMult_);
            const uint64_t row = baseTask / tilesPerRow_;
            const uint64_t columnOffset = (baseTask % tilesPerRow_) * tileLength_;
            const uint32_t validLength = static_cast<uint32_t>(
                ((d_ - columnOffset) < tileLength_) ? (d_ - columnOffset) : tileLength_);
            const uint32_t alignedLength = AlignUp(validLength);
            const uint64_t inputOffset = row * d_ + columnOffset;
            const uint64_t outputOffset = (row * mhcMult_ + replica) * d_ + columnOffset;

            AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(mte3ToMte2);
            if (IsBlockAligned(inputOffset, validLength)) {
                AscendC::DataCopy(xLocal, xGm_[inputOffset], alignedLength);
            } else {
                const uint32_t copyBytes = validLength * static_cast<uint32_t>(sizeof(DT_X));
                AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
                AscendC::DataCopyPadExtParams<DT_X> padParams{
                    true, 0, static_cast<uint8_t>(alignedLength - validLength), static_cast<DT_X>(0)};
                AscendC::DataCopyPad(xLocal, xGm_[inputOffset], copyParams, padParams);
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(mte2ToMte3);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(mte2ToMte3);
            if (IsBlockAligned(outputOffset, validLength)) {
                AscendC::DataCopy(oGm_[outputOffset], xLocal, alignedLength);
            } else {
                const uint32_t copyBytes = validLength * static_cast<uint32_t>(sizeof(DT_X));
                AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
                AscendC::DataCopyPad(oGm_[outputOffset], xLocal, copyParams);
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(mte3ToMte2);
        }
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(mte3ToMte2);
    }

    __aicore__ inline void ProcessBackward(uint64_t row, uint64_t columnOffset,
                                            uint32_t validLength, uint32_t alignedLength) {
        if constexpr (AscendC::IsSameType<DT_X, half>::value) {
            if (mhcMult_ == 2) {
                ProcessBackwardPair(row, columnOffset, validLength, alignedLength);
                return;
            }
        }
        AscendC::LocalTensor<float> valueFp32 = valueFp32Buf_.Get<float>();
        AscendC::LocalTensor<float> accumulator = accFp32Buf_.Get<float>();
        const uint64_t rowBaseOffset = row * mhcMult_ * d_ + columnOffset;
        CopyIn(rowBaseOffset, validLength, alignedLength);

        for (uint32_t replica = 0; replica < mhcMult_; ++replica) {
            AscendC::LocalTensor<DT_X> xLocal = inQueue_.DeQue<DT_X>();
            if (replica + 1 < mhcMult_) {
                CopyIn(rowBaseOffset + (replica + 1) * d_, validLength, alignedLength);
            }
            if (replica == 0) {
                // Casting the first replica directly initializes the FP32
                // accumulator, removing Duplicate plus one vector Add.
                AscendC::Cast(accumulator, xLocal, AscendC::RoundMode::CAST_NONE, alignedLength);
            } else {
                AscendC::Cast(valueFp32, xLocal, AscendC::RoundMode::CAST_NONE, alignedLength);
                AscendC::PipeBarrier<PIPE_V>();
                AscendC::Add(accumulator, accumulator, valueFp32, alignedLength);
            }
            AscendC::PipeBarrier<PIPE_V>();
            inQueue_.FreeTensor(xLocal);
        }

        AscendC::LocalTensor<DT_X> oLocal = outQueue_.AllocTensor<DT_X>();
        CastFromFloat(oLocal, accumulator, alignedLength);
        outQueue_.EnQue(oLocal);
        oLocal = outQueue_.DeQue<DT_X>();
        CopyOut(oLocal, row * d_ + columnOffset, validLength);
        outQueue_.FreeTensor(oLocal);
    }

    __aicore__ inline void ProcessBackwardPair(uint64_t row, uint64_t columnOffset,
                                                uint32_t validLength, uint32_t alignedLength) {
        const uint64_t rowBaseOffset = row * 2 * d_ + columnOffset;
        CopyIn(rowBaseOffset, validLength, alignedLength);
        AscendC::LocalTensor<DT_X> x0Local = inQueue_.DeQue<DT_X>();
        CopyIn(rowBaseOffset + d_, validLength, alignedLength);
        AscendC::LocalTensor<DT_X> x1Local = inQueue_.DeQue<DT_X>();

        // For exactly two FP16/BF16 operands, direct addition has the same
        // final rounding as an exact FP32 sum followed by one cast back.
        AscendC::LocalTensor<DT_X> oLocal = outQueue_.AllocTensor<DT_X>();
        AscendC::Add(oLocal, x0Local, x1Local, alignedLength);
        outQueue_.EnQue(oLocal);
        inQueue_.FreeTensor(x0Local);
        inQueue_.FreeTensor(x1Local);

        oLocal = outQueue_.DeQue<DT_X>();
        CopyOut(oLocal, row * d_ + columnOffset, validLength);
        outQueue_.FreeTensor(oLocal);
    }

    AscendC::TPipe pipe_;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue_;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> valueFp32Buf_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> accFp32Buf_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> forwardBuf_;
    AscendC::GlobalTensor<DT_X> xGm_;
    AscendC::GlobalTensor<DT_X> oGm_;
    uint64_t s_ = 0;
    uint64_t d_ = 0;
    uint64_t tilesPerRow_ = 0;
    uint32_t mhcMult_ = 0;
    uint32_t tileLength_ = 0;
    uint32_t blockDim_ = 0;
    bool backward_ = false;
};

template <typename DT_X>
__global__ __aicore__ void mhc_expand(GM_ADDR x, GM_ADDR o, GM_ADDR workspace, GM_ADDR tiling) {
    REGISTER_TILING_DEFAULT(MhcExpandTilingData);
    GET_TILING_DATA_WITH_STRUCT(MhcExpandTilingData, tiling_data, tiling);
    KernelMhcExpand<DT_X> op;
    op.Init(x, o, tiling_data);
    op.Process();
}
