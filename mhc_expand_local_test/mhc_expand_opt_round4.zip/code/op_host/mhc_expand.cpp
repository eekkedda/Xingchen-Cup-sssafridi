// Host-side shape/type inference and tiling for MhcExpand.
#include <algorithm>
#include <cstdint>
#include <limits>

#include "register/op_def_registry.h"
#include "tiling/platform/platform_ascendc.h"

#include "../op_kernel/mhc_expand_tiling.h"
#include "../op_kernel/tiling_key_mhc_expand.h"

namespace optiling {
constexpr uint32_t TILE_LENGTH = 8192;
constexpr uint32_t MIN_TILE_LENGTH = 512;
constexpr uint32_t ELEMENTS_PER_BLOCK = 16;  // Both supported dtypes are 2 bytes.

// Keep the large tile when rows alone expose enough work.  For small S, shrink
// it only as far as needed to give every AIV core an independent D tile.
static uint32_t SelectTileLength(uint64_t s, uint64_t d, uint32_t numCoresAiv) {
    const uint64_t alignedD =
        (d + ELEMENTS_PER_BLOCK - 1) / ELEMENTS_PER_BLOCK * ELEMENTS_PER_BLOCK;
    uint64_t tileLength = std::min<uint64_t>(TILE_LENGTH, alignedD);
    const uint64_t tilesNeeded =
        (static_cast<uint64_t>(numCoresAiv) + s - 1) / s;
    if (tilesNeeded > 1 && d > 1) {
        // ceil(d / tileLength) >= tilesNeeded iff
        // tileLength <= floor((d - 1) / (tilesNeeded - 1)).
        const uint64_t maxTileForParallelism = (d - 1) / (tilesNeeded - 1);
        const uint64_t alignedParallelTile =
            (maxTileForParallelism / ELEMENTS_PER_BLOCK) * ELEMENTS_PER_BLOCK;
        if (alignedParallelTile >= MIN_TILE_LENGTH) {
            tileLength = std::min(tileLength, alignedParallelTile);
        } else {
            // Very small DMA blocks lose more to command latency than they gain
            // from exposing additional cores.
            tileLength = std::min<uint64_t>(tileLength, MIN_TILE_LENGTH);
        }
    }
    return static_cast<uint32_t>(tileLength);
}

static ge::graphStatus TilingFunc(gert::TilingContext *context) {
    if (context == nullptr || context->GetInputShape(0) == nullptr ||
        context->GetInputDesc(0) == nullptr || context->GetAttrs() == nullptr) {
        return ge::GRAPH_FAILED;
    }

    auto platform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    const int32_t numCoresAiv = platform.GetCoreNumAiv();
    if (numCoresAiv <= 0) {
        return ge::GRAPH_FAILED;
    }

    const gert::RuntimeAttrs *attrs = context->GetAttrs();
    const int64_t *attrMhcMult = attrs->GetInt(0);
    const bool *attrBackward = attrs->GetBool(1);
    if (attrMhcMult == nullptr || attrBackward == nullptr || *attrMhcMult <= 0 ||
        static_cast<uint64_t>(*attrMhcMult) > std::numeric_limits<uint32_t>::max()) {
        return ge::GRAPH_FAILED;
    }

    const gert::Shape &inputShape = context->GetInputShape(0)->GetOriginShape();
    const size_t expectedRank = *attrBackward ? 3 : 2;
    if (inputShape.GetDimNum() != expectedRank) {
        return ge::GRAPH_FAILED;
    }

    const int64_t sDim = inputShape.GetDim(0);
    const int64_t dDim = inputShape.GetDim(*attrBackward ? 2 : 1);
    if (sDim <= 0 || dDim <= 0) {
        return ge::GRAPH_FAILED;
    }
    if (*attrBackward && inputShape.GetDim(1) != *attrMhcMult) {
        return ge::GRAPH_FAILED;
    }

    const uint64_t s = static_cast<uint64_t>(sDim);
    const uint64_t d = static_cast<uint64_t>(dDim);
    const uint32_t tileLength =
        SelectTileLength(s, d, static_cast<uint32_t>(numCoresAiv));
    const uint64_t tilesPerRow = (d + tileLength - 1) / tileLength;
    if (s > std::numeric_limits<uint64_t>::max() / tilesPerRow) {
        return ge::GRAPH_FAILED;
    }
    const uint64_t taskCount = s * tilesPerRow;
    uint64_t parallelTaskCount = taskCount;
    if (!*attrBackward && taskCount < static_cast<uint64_t>(numCoresAiv)) {
        if (taskCount > std::numeric_limits<uint64_t>::max() /
                            static_cast<uint64_t>(*attrMhcMult)) {
            return ge::GRAPH_FAILED;
        }
        // When S and D still cannot occupy all cores, independent replicas are
        // faster than serial MTE3 writes from a single core.  The kernel detects
        // this mode from blockDim > taskCount.
        parallelTaskCount = taskCount * static_cast<uint64_t>(*attrMhcMult);
    }
    const uint32_t blockDim = static_cast<uint32_t>(
        std::min<uint64_t>(static_cast<uint64_t>(numCoresAiv), parallelTaskCount));

    const ge::DataType dtypeX = context->GetInputDesc(0)->GetDataType();
    uint32_t DT_X = static_cast<uint32_t>(dtypeX);
    ASCENDC_TPL_SEL_PARAM(context, DT_X);

    MhcExpandTilingData *tiling = context->GetTilingData<MhcExpandTilingData>();
    if (tiling == nullptr) {
        return ge::GRAPH_FAILED;
    }
    tiling->s = s;
    tiling->d = d;
    tiling->mhcMult = static_cast<uint32_t>(*attrMhcMult);
    tiling->backward = *attrBackward ? 1U : 0U;
    tiling->tileLength = tileLength;
    tiling->blockDim = blockDim;

    context->SetBlockDim(blockDim);
    size_t *currentWorkspace = context->GetWorkspaceSizes(1);
    if (currentWorkspace == nullptr) {
        return ge::GRAPH_FAILED;
    }
    currentWorkspace[0] = 0;
    return ge::GRAPH_SUCCESS;
}
}  // namespace optiling

namespace ge {
static graphStatus InferShape(gert::InferShapeContext *context) {
    if (context == nullptr || context->GetInputShape(0) == nullptr ||
        context->GetOutputShape(0) == nullptr || context->GetAttrs() == nullptr) {
        return GRAPH_FAILED;
    }

    const gert::Shape *inputShape = context->GetInputShape(0);
    gert::Shape *outputShape = context->GetOutputShape(0);
    const int64_t *mhcMult = context->GetAttrs()->GetInt(0);
    const bool *backward = context->GetAttrs()->GetBool(1);
    if (mhcMult == nullptr || backward == nullptr || *mhcMult <= 0) {
        return GRAPH_FAILED;
    }

    if (*backward) {
        if (inputShape->GetDimNum() != 3 ||
            (inputShape->GetDim(1) >= 0 && inputShape->GetDim(1) != *mhcMult)) {
            return GRAPH_FAILED;
        }
        outputShape->SetDimNum(2);
        outputShape->SetDim(0, inputShape->GetDim(0));
        outputShape->SetDim(1, inputShape->GetDim(2));
    } else {
        if (inputShape->GetDimNum() != 2) {
            return GRAPH_FAILED;
        }
        outputShape->SetDimNum(3);
        outputShape->SetDim(0, inputShape->GetDim(0));
        outputShape->SetDim(1, *mhcMult);
        outputShape->SetDim(2, inputShape->GetDim(1));
    }
    return GRAPH_SUCCESS;
}

static graphStatus InferDataType(gert::InferDataTypeContext *context) {
    if (context == nullptr) {
        return GRAPH_FAILED;
    }
    context->SetOutputDataType(0, context->GetInputDataType(0));
    return GRAPH_SUCCESS;
}
}  // namespace ge

namespace ops {
class MhcExpand : public OpDef {
public:
    explicit MhcExpand(const char *name) : OpDef(name) {
        this->Input("x")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("o")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Attr("mhc_mult").AttrType(OPTIONAL).Int(2);
        this->Attr("backward").AttrType(OPTIONAL).Bool(false);
        this->SetInferShape(ge::InferShape).SetInferDataType(ge::InferDataType);
        this->AICore()
            .SetTiling(optiling::TilingFunc)
            .AddConfig("ascend910b");
    }
};
OP_ADD(MhcExpand);
}  // namespace ops
