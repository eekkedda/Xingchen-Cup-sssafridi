// Host-to-kernel tiling data for MhcExpand.
#pragma once

#include <cstdint>

struct MhcExpandTilingData {
    uint64_t s;
    uint64_t d;
    uint32_t mhcMult;
    uint32_t backward;
    uint32_t tileLength;
    uint32_t rowBlock;
    uint32_t blockDim;
    // Backward grouped-read fast path (plan D): when one row fits a tile,
    // D is 16-element aligned, and the whole m*D token block fits the UB
    // budget, each token's m contiguous GM streams are fetched with a single
    // DMA into one ping-pong slot; rowBlock is forced to 1 so every replica
    // slice stays contiguous and aligned in UB.
    uint32_t bwdGrouped;
};
static_assert(sizeof(MhcExpandTilingData) == 40, "unexpected tiling ABI size");

